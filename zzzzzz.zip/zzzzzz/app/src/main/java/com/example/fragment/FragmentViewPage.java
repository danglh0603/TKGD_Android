package com.example.fragment;

import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager2.adapter.FragmentStateAdapter;




public class FragmentViewPage extends FragmentStatePagerAdapter {
    int mNumberPage;

    public FragmentViewPage( FragmentManager fm, int mNumberPage) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        return Pagefragment.newInstance("Fragment "+position);
    }

    @Override
    public int getCount() {
        return mNumberPage;
    }
}
