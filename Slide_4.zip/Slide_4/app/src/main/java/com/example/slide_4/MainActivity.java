package com.example.slide_4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Toolbar toolbar = findViewById(R.id.myToolBar);
//        toolbar.setLogo(R.drawable.vn);
//        setSupportActionBar(toolbar);
        Toolbar toolbar = findViewById(R.id.myToolBar);
        toolbar.setLogo(R.drawable.vn);
        setSupportActionBar(toolbar);

        // hiển thị nút back
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);


        // === bottom nav
//        BottomNavigationView btn_nav = findViewById(R.id.bt_nav);
//        btn_nav.setOnItemSelectedListener(Menu m);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu01, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Toast.makeText(this,"Bạn chọn"+ item.getItemId(),Toast.LENGTH_SHORT).show();
        return true;
    }
}