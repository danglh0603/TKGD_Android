package com.example.slide3;

public class Sinhvien {
    int id, hinhAnh;
    String hoTen;

    public Sinhvien() {
    }

    public Sinhvien(int id, int hinhAnh, String hoTen) {
        this.id = id;
        this.hinhAnh = hinhAnh;
        this.hoTen = hoTen;
    }
}
