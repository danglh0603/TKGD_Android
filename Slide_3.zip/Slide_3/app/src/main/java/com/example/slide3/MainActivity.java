package com.example.slide3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        DemoSimpleAdapter();
        //1, tạo ds đối tượng
        ArrayList<Sinhvien> lstSv = new ArrayList<>();
        lstSv.add(new Sinhvien(1,R.drawable.img4,"LE HAI DANG"));
        lstSv.add(new Sinhvien(2,R.drawable.img4,"LE HAI DANG"));
        lstSv.add(new Sinhvien(3,R.drawable.img4,"LE HAI DANG"));
        lstSv.add(new Sinhvien(4,R.drawable.img4,"LE HAI DANG"));
        lstSv.add(new Sinhvien(5,R.drawable.img4,"LE HAI DANG"));
        //2, tạo adapter
        SinhVienAdapter sinhVienAdapter = new SinhVienAdapter(lstSv, MainActivity.this);
        //3, gán vào list view

        ListView ViewSv = findViewById(R.id.lstSv);
        ViewSv.setAdapter(sinhVienAdapter);





    }

    void DemoSimpleAdapter(){
        // 1, nguồn dữ liệu  sv: hoTen, hinhAnh
        List< HashMap<String, Object>   > dsSv = new ArrayList<>();
        // tạo đối tượng cho vào danh sách
        HashMap<String, Object> objSv = new HashMap<String, Object>();
        objSv.put("hoTen","Sinh viên 01");
        objSv.put("hinhAnh",R.drawable.img4);
        dsSv.add(objSv); // đưa obj vào ds

        objSv = new HashMap<String, Object>();
        objSv.put("hoTen","Sinh viên 02");
        objSv.put("hinhAnh",R.drawable.img5);
        dsSv.add(objSv);

        objSv = new HashMap<String, Object>();
        objSv.put("hoTen","Sinh viên 03");
        objSv.put("hinhAnh",R.drawable.img4);
        dsSv.add(objSv);

        objSv = new HashMap<String, Object>();
        objSv.put("hoTen","Sinh viên 04");
        objSv.put("hinhAnh",R.drawable.img5);
        dsSv.add(objSv);


        //////////// tạo adapter

        String [] mang_thuoc_tinh = {"hoTen", "hinhAnh"};
        int [] mang_id_view = {R.id.tvhoTen, R.id.imgAnhsv};

        SimpleAdapter simpleAdapter =
                new SimpleAdapter(MainActivity.this,dsSv,R.layout.layout_item_sv
                                                        ,mang_thuoc_tinh,mang_id_view);


        // gán adapter cho view ds
        GridView gridView = findViewById(R.id.grv_sv);
        gridView.setAdapter(simpleAdapter);


    }
}