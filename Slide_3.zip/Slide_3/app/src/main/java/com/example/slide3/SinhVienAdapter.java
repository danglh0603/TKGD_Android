package com.example.slide3;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class SinhVienAdapter extends BaseAdapter {


    ArrayList<Sinhvien> dsSv ;
    Context context;

    public SinhVienAdapter(ArrayList<Sinhvien> dsSv, Context context) {
        this.dsSv = dsSv;
        this.context = context;
    }

    @Override
    public int getCount() {
        return dsSv.size();
    }

    @Override
    public Object getItem(int position) {
        return dsSv.get(position);
    }

    @Override
    public long getItemId(int position) {
        return dsSv.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d("zzzzzz", "getView: lấy phần tử thứ "+position);

        View itemView;
        if (convertView == null){
            // khi app bắt đầu chạy thì khởi tạo convertview
            itemView = View.inflate(parent.getContext(),R.layout.layout_item_sv,null);
        }else {
            itemView = convertView;
        }

        // gán dữ liệu hiển thị view
        Sinhvien objSv = dsSv.get(position);
        TextView tv_hoTen = itemView.findViewById(R.id.tvhoTen);
        ImageView img_Sv = itemView.findViewById(R.id.imgAnhsv);

        tv_hoTen.setText(objSv.hoTen);
        img_Sv.setImageResource(objSv.hinhAnh);




        return itemView;
    }
}
