package com.example.vd_appbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.mytoolbar01);
//        toolbar.setLogo(R.drawable.devmob);
        setSupportActionBar(toolbar);

        // hiển thị nút back
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);

        //=========== bottom nav
        BottomNavigationView btn_nav = findViewById(R.id.bt_nav);
        btn_nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.m_01:
                        Toast.makeText(MainActivity.this, "Bạn chọn liên hẹ", Toast.LENGTH_SHORT).show();
                        break;
                    case  R.id.m_02:
                        Toast.makeText(MainActivity.this, "Bạn chọn cập nhật", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.m_03:
                        Toast.makeText(MainActivity.this, "Tạm biệt", Toast.LENGTH_SHORT).show();
                        break;
                }
                return false;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_01, menu);
        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Toast.makeText(this, "Bạn chọn: " + item.getItemId(), Toast.LENGTH_SHORT).show();

        return true;
    }
}