package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    RadioButton rdoA, rdoD,rdoC,rdoB;
    RadioGroup rdoG;
    Button btnsubmit;
    CheckBox chk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        rdoG = findViewById(R.id.rdoGroup);
        rdoA = (RadioButton) findViewById(R.id.rdoA);
        rdoB = (RadioButton) findViewById(R.id.rdoB);
        rdoC = (RadioButton) findViewById(R.id.rdoC);
        rdoD = (RadioButton) findViewById(R.id.rdoD);
        btnsubmit = (Button) findViewById(R.id.btnsubmit);
        chk = findViewById(R.id.chkXn);

    }
    public void check(View view){
        if(!chk.isChecked()){
            Toast.makeText(this,"Ban can xac nhan?",Toast.LENGTH_SHORT).show();
            return;
        }

        if(rdoB.isChecked()==true){
            Toast.makeText(this,"Chinh xac",Toast.LENGTH_SHORT).show();
            Intent in = new Intent(MainActivity.this,MainActivity2.class);
            startActivity(in);
        }else {
            Toast.makeText(this,"Sai",Toast.LENGTH_SHORT).show();

        }
    }
}