package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    TextView tvquestion;
    ImageView imgView;
    RadioGroup rdoGroup;
    RadioButton rdoA;
    RadioButton rdoB;
    RadioButton rdoC;
    RadioButton rdoD;
    CheckBox chkXn;
    Button btnsubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        tvquestion = findViewById(R.id.tvquestion);
        imgView = findViewById(R.id.imgView);
        rdoGroup = findViewById(R.id.rdoGroup);
        rdoA = findViewById(R.id.rdoA);
        rdoB = findViewById(R.id.rdoB);
        rdoC = findViewById(R.id.rdoC);
        rdoD = findViewById(R.id.rdoD);
        chkXn = findViewById(R.id.chkXn);
        btnsubmit = findViewById(R.id.btnsubmit);

        tvquestion.setText("Day la con gi?");
        imgView.setImageResource(R.drawable.img5);
        rdoA.setText("Dog");
        rdoB.setText("Cat");
        rdoC.setText("Wolf");
        rdoD.setText("Pig");
    }
    public void check(View view){
        if(!chkXn.isChecked()){
            Toast.makeText(this,"Ban can xac nhan?",Toast.LENGTH_SHORT).show();
            return;
        }

        if(rdoC.isChecked()==true){
            Toast.makeText(this,"Chinh xac",Toast.LENGTH_SHORT).show();
            Intent in = new Intent(MainActivity2.this,MainActivity3.class);
            startActivity(in);
        }else {
            Toast.makeText(this,"Sai",Toast.LENGTH_SHORT).show();

        }
    }
}