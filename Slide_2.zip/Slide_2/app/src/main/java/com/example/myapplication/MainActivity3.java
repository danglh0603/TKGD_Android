package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {

    TextView tvquestion;
    ImageView imgView;
    RadioGroup rdoGroup;
    RadioButton rdoA;
    RadioButton rdoB;
    RadioButton rdoC;
    RadioButton rdoD;
    CheckBox chkXn;
    Button btnsubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        tvquestion = findViewById(R.id.tvquestion);
        rdoGroup = findViewById(R.id.rdoGroup);
        rdoA = findViewById(R.id.rdoA);
        rdoB = findViewById(R.id.rdoB);
        rdoC = findViewById(R.id.rdoC);
        rdoD = findViewById(R.id.rdoD);
        chkXn = findViewById(R.id.chkXn);
        btnsubmit = findViewById(R.id.btnsubmit);

        tvquestion.setText("Ban co ngu k?");
        rdoA.setText("Co");
        rdoB.setText("Tat nhien r");
        rdoC.setText("Hoi thua");
        rdoD.setText("Duong nhien la co");

        if(chkXn.isChecked()){
            Toast.makeText(this,"Ban ngu :)))",Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this,"Ban ngu :)))",Toast.LENGTH_SHORT).show();
        }

    }
    public void check(View view){
        if(rdoB.isChecked()==true){
            Toast.makeText(this,"Chinh xac",Toast.LENGTH_SHORT).show();

        }
        if(rdoA.isChecked()==true) {
            Toast.makeText(this,"Dung roi",Toast.LENGTH_SHORT).show();

        }
        if(rdoC.isChecked()==true) {
            Toast.makeText(this,"Dung luon",Toast.LENGTH_SHORT).show();

        }
        if(rdoD.isChecked()==true) {
            Toast.makeText(this,"Qua dung",Toast.LENGTH_SHORT).show();
        }
    }
}