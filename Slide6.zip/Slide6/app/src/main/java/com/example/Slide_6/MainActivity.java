package com.example.Slide_6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity {
    Frag_01 frag_01;
    Frag_02 frag_02;
    FragmentManager fm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);   // dung cho TH gan co dinh fragment tren layout

        // goi fragment dong
        setContentView(R.layout.main_layout);
        fm = getSupportFragmentManager();
        frag_01 = new Frag_01();
        frag_02 = new Frag_02();
        // hien thi frag mac dinh
        fm.beginTransaction()
                .add(R.id.fag_container,frag_01)
                .commit();

        Button b1 = findViewById(R.id.btn_1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm.beginTransaction()
                        .replace(R.id.fag_container,frag_01)   // ham thay the frag1 vi khi chay app da add frag1 r
                        .commit();
            }
        });

        Button b2 = findViewById(R.id.btn_2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fm.beginTransaction()
                        .add(R.id.fag_container,frag_02)
                        .commit();
            }
        });


    }
}