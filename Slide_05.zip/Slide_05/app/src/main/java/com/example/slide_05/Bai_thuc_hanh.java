package com.example.slide_05;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Bai_thuc_hanh extends AppCompatActivity {
    TextView tv1, tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai_thuc_hanh);
        tv1 = findViewById(R.id.tv_Time);
        tv2 = findViewById(R.id.tv_newTime);
        DatePicker datePicker = findViewById(R.id.dpk_time);


        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());

        datePicker.init(
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DATE),
                new DatePicker.OnDateChangedListener() {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        tv1.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
                    }
                }
        );


    }

    public void chuyenDoi(View view) {
            String old_chuoi = tv1.getText().toString();
            DateFormat dateFormat = new DateFormat();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

            try {
                Date objDateNew = simpleDateFormat.parse(old_chuoi);
                tv2.setText(dateFormat.format("dd/MM/yyyy", objDateNew));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    
}