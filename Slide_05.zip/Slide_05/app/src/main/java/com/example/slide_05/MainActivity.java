package com.example.slide_05;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    final String TAG = "zzzzz";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.edt_ngay);
       //editText.setEnabled(false);
        DatePicker datePicker = findViewById(R.id.dpk_01);

        // sử dụng đối tượng lịch(Calendar) để thiết lập ngày tháng mặc định cho picker

        Calendar calendar = Calendar.getInstance();// lấy thông tin về lịch hiện tại trên điện thoại
        calendar.setTimeInMillis(System.currentTimeMillis());

        // khởi tạo hoạt động cho picker
        datePicker.init(
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DATE),
                new DatePicker.OnDateChangedListener() {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        editText.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }
                });


        ////=========================================================
        // CHUYỂN ĐỊNH DẠNG THỜI GIAN

        // ----lấy ngày : ngày/tháng/năm , mẫu: dd/MM/yyyy


        Date objDate = new Date(System.currentTimeMillis());

        android.text.format.DateFormat objFormat = new DateFormat();
        String chuoi_ngay = (String) objFormat.format("dd/MM/yyyy", objDate);

        Log.d(TAG, chuoi_ngay);
        //----------- ví dụ chuyển định dạng khác
        //----------- lưu csdl: yyyy-MM-dd , còn định dạng hiển thị dd/MM/yyyy
        // giả sử lấy từ CSDL đưa lên giao diện ==> cần chuyển định dạng
        String chuoi = "2021-08-21";
        Log.d(TAG, chuoi);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); // định dạng đầu vào
        try {
            Date objDateNew = dateFormat.parse(chuoi);
            Log.d(TAG, "onCreate: Kết quả " + objFormat.format("dd/MM/yyyy", objDateNew));
        } catch (Exception e) {
            Log.e(TAG, "onCreate: Lỗi chuyển định dạng");
            e.printStackTrace();
        }


    }

    //=============== DIALOG ==========
    public void Dialog(View view) {
        Calendar calendar = Calendar.getInstance();// lấy thông tin về lịch hiện tại trên điện thoại
        calendar.setTimeInMillis(System.currentTimeMillis());

        DatePickerDialog dialog = new DatePickerDialog(MainActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        editText.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    }
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DATE)

        );
        dialog.show();


    }


    public void Baithuchanh(View view){
        Intent in = new Intent(MainActivity.this, Bai_thuc_hanh.class);
        startActivity(in);
    }
}