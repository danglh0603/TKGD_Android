package com.example.slide_6_part2;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import org.jetbrains.annotations.NotNull;

public class MyPaperAdapter extends FragmentStateAdapter {
    int numberPage = 3;
    public MyPaperAdapter(@NonNull @NotNull Fragment fragment) {
        super(fragment);
    }

    @NonNull
    @NotNull
    @Override
    public Fragment createFragment(int position) {
        Fragment fragment;
        switch (position){
//            case 0:{  // fragment dau tien
//                fragment = new FragViewPager();
//                break;
//            }
            case 1:{    // fragment 2
                fragment = new FragViewPager02();
                break;
            }
            default:{
                fragment = new FragViewPager();
                break;
            }
        }


        return fragment;
    }

    @Override
    public int getItemCount() {
        return numberPage;
    }
}
