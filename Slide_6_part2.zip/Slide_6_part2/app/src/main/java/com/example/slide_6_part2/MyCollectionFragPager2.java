package com.example.slide_6_part2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import org.jetbrains.annotations.NotNull;

public class MyCollectionFragPager2 extends Fragment {

    MyPaperAdapter adapter;
    ViewPager2 viewPager2;

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_frag_colection, container, false);
    }


    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        adapter = new MyPaperAdapter(this);
        viewPager2 = view.findViewById(R.id.pager2_demo);
        viewPager2.setAdapter(adapter);
        //----------------------------
        TabLayout tabLayout = view.findViewById(R.id.tabLayout);

//        TabLayoutMediator mediator = new TabLayoutMediator(tabLayout, viewPager2,
//                new TabLayoutMediator.TabConfigurationStrategy() {
//                    @Override
//                    public void onConfigureTab(@NonNull @NotNull TabLayout.Tab tab, int position) {
//                        //tab.setText("tieu de tab " + position);
//                        switch (position) {
//                            case 0: {
//                                tab.setText("Loai thu");
//                                break;
//                            }
//                            case 1: {
//                                tab.setText("Khoan thu");
//                                break;
//                            }
//                            default: {
//                                tab.setText("tab " + position + 1);
//                                break;
//                            }
//                        }
//
//                    }
//                });
//        mediator.attach();
        //===================================


       /*  int TimTong( int a, int b){return a+b}
         cach viet ham mui ten: (a+b)->{return a+b};


         void TinhTong(int a, int b){
         log.d("tag", a+b);}
         cach viet ham mui ten: (a+b)->{log.d("tag", a+b);}
         */

        TabLayoutMediator mediator1 = new TabLayoutMediator(tabLayout, viewPager2,
                (tab, position) -> {
                    switch (position) {
                        case 0: {
                            tab.setText("Loai thu");
                            break;
                        }
                        case 1: {
                            tab.setText("Khoan thu");
                            break;
                        }
                        default: {
                            tab.setText("tab " + position + 1);
                            break;
                        }
                    }
                }
        );
        mediator1.attach();


    }











}
