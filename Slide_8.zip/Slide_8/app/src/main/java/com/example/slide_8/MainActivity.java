package com.example.slide_8;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.navigation.NavigationView;

import org.jetbrains.annotations.NotNull;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Frag_01 frag_01;
    Frag_02 frag_02;
    FragmentManager fm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // thiet lap toolbar
        toolbar = findViewById(R.id.main_toobar);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.outline_menu_black_24);
        actionBar.setDisplayHomeAsUpEnabled(true);

        //========= anh xa drawer
        drawerLayout = findViewById(R.id.drw_layout);
        navigationView = findViewById(R.id.drw_nav_view);
        //======== fragment
        frag_01 = new Frag_01();
        frag_02 = new Frag_02();
        fm = getSupportFragmentManager();
        fm.beginTransaction().add(R.id.frag_container, frag_01).commit();

        // su li su kien bam menu

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.mnu_01: {
                        fm.beginTransaction().replace(R.id.frag_container, frag_01).commit();
                        break;
                    }
                    case R.id.mnu_02: {
                        fm.beginTransaction().replace(R.id.frag_container, frag_02).commit();
                        break;
                    }
                    default: {
                        Toast.makeText(MainActivity.this, "ban chon menu", Toast.LENGTH_SHORT).show();
                    }
                }
                drawerLayout.closeDrawer(navigationView);
                return false;
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            drawerLayout.openDrawer(navigationView);
        }
        return super.onOptionsItemSelected(item);
    }
}