package com.example.tuannkph15655_ass1.classDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.example.tuannkph15655_ass1.classs.KhoanThu;
import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.database.Database;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.util.Calendar.DATE;

public class KhoanThuDao {
    SQLiteDatabase sqLiteDatabase;
    Database database;
    private Context context;
    public KhoanThuDao(Context context) {
        database = new Database(context);
        sqLiteDatabase = database.getWritableDatabase();
    }
    public static final String TABLE_NAME_KHOANTHU = Database.TABLE_NAME_KHOANTHU;

    public void themKhoanThu(KhoanThu khoanThu){
        ContentValues values = new ContentValues();
        //values.put("idKhoanThu",khoanThu.getIdKhoanThu());
        values.put("idLoaiThu", khoanThu.getIdLoaiThu());
        values.put("tenLoaiThu", khoanThu.getTenLoaiThu());
        values.put("tenKhoanThu", khoanThu.getTenKhoanThu());
        values.put("ngayThu", khoanThu.getNgayThu());
        values.put("soTien",khoanThu.getSoTienThu());
        values.put("noiDung", khoanThu.getNoiDung());


        long kq = sqLiteDatabase.insert(TABLE_NAME_KHOANTHU,null,values);
        if(kq >0){
            Log.e("Them", "thanh cong");
        }else {
            Log.e("Them", " khong thanh cong");
        }

    }
    public void suaKhoanThu(KhoanThu khoanThu){
        ContentValues values = new ContentValues();
//        values.put("idKhoanThu",khoanThu.getIdKhoanThu());
//        values.put("idLoaiThu", khoanThu.getIdLoaiThu());
        values.put("tenLoaiThu", khoanThu.getTenLoaiThu());
        values.put("tenKhoanThu", khoanThu.getTenKhoanThu());
        values.put("ngayThu", khoanThu.getNgayThu());
        values.put("soTien",khoanThu.getSoTienThu());
        values.put("noiDung", khoanThu.getNoiDung());


        long kq = sqLiteDatabase.update(TABLE_NAME_KHOANTHU,values,"idKhoanThu=?",new String[]{khoanThu.getIdKhoanThu() + ""});
        if(kq >0){
            Log.e("sua", "thanh cong");
        }else {
            Log.e("sua", " khong thanh cong");
        }
    }
    public void xoaKhoanThu(KhoanThu khoanThu){
        ContentValues values = new ContentValues();


        long kq = sqLiteDatabase.delete(TABLE_NAME_KHOANTHU,"idKhoanThu=?",new String[]{khoanThu.getIdKhoanThu()+ ""});
        if(kq >0){
            Log.e("xoa", "thanh cong");
        }else {
            Log.e("xoa", " khong thanh cong");
        }

    }

    public ArrayList<KhoanThu> danhSachKhoanThu() {
        ArrayList<KhoanThu> listKhoanThu = new ArrayList<KhoanThu>();
        String getAll = "select*from " + TABLE_NAME_KHOANTHU;
        Cursor cursor = sqLiteDatabase.rawQuery(getAll, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int idKhoanThu = cursor.getInt(0);
                int idLoaiThu = cursor.getInt(1);
                String tenLoaiThu = cursor.getString(2);
                String tenKhoanThu = cursor.getString(3);
                String ngayThu = cursor.getString(4);
                String soTien = cursor.getString(5);
                String noiDung = cursor.getString(6);

                KhoanThu khoanThu = new KhoanThu(idKhoanThu, idLoaiThu, tenLoaiThu, tenKhoanThu, ngayThu, noiDung, soTien);
                listKhoanThu.add(khoanThu);
                cursor.moveToNext();
            }
        }
        return listKhoanThu;
    }
    public ArrayList<KhoanThu> thongKeKhoanThu(String batDau, String ketThuc) {
        ArrayList<KhoanThu> listKhoanThu = new ArrayList<KhoanThu>();
        String getAll = "select*from " + TABLE_NAME_KHOANTHU + " WHERE DATE(ngayThu) BETWEEN " +batDau+ " AND " + ketThuc;
        Cursor cursor = sqLiteDatabase.rawQuery(getAll, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int idKhoanThu = cursor.getInt(0);
                int idLoaiThu = cursor.getInt(1);
                String tenLoaiThu = cursor.getString(2);
                String tenKhoanThu = cursor.getString(3);
                String ngayThu = cursor.getString(4);
                String soTien = cursor.getString(5);
                String noiDung = cursor.getString(6);

                KhoanThu khoanThu = new KhoanThu(idKhoanThu, idLoaiThu, tenLoaiThu, tenKhoanThu, ngayThu, noiDung, soTien);
                listKhoanThu.add(khoanThu);
                cursor.moveToNext();
            }
        }
        Log.e("size thong ke", listKhoanThu.size() + "");
        return listKhoanThu;
    }
}
