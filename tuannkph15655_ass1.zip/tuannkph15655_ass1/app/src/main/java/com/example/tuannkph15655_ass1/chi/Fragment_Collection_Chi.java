package com.example.tuannkph15655_ass1.chi;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.tuannkph15655_ass1.R;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import org.jetbrains.annotations.NotNull;

public class Fragment_Collection_Chi extends Fragment {
    Adapter_Pager_Chi adapter_pager_chi;
    ViewPager2 viewPager2;
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_collection_chi, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        adapter_pager_chi = new Adapter_Pager_Chi(this);

        viewPager2 = view.findViewById(R.id.pager_chi);
        viewPager2.setSaveEnabled(false);
        viewPager2.setAdapter(adapter_pager_chi);


        String textTab [] = {"Loại chi", "Khoản chi"};
        TabLayout tabLayout = view.findViewById(R.id.tab_chi);
        TabLayoutMediator mediator = new TabLayoutMediator(tabLayout, viewPager2, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull @NotNull TabLayout.Tab tab, int position) {
                tab.setText(textTab[position]);
            }
        });
        mediator.attach();
    }
}
