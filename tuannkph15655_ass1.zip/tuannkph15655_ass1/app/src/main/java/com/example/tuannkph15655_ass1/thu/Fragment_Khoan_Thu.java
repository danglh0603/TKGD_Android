package com.example.tuannkph15655_ass1.thu;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.adapter.KhoanThu_Adapter;
import com.example.tuannkph15655_ass1.adapter.LoaiThu_Adapter;
import com.example.tuannkph15655_ass1.chi.Fragment_Collection_Chi;
import com.example.tuannkph15655_ass1.classDao.KhoanThuDao;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.KhoanThu;
import com.example.tuannkph15655_ass1.classs.LoaiThu;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Fragment_Khoan_Thu extends Fragment {
    //item spn ngay thu
    String item_spn;

    View viewKhoanThu;
    LayoutInflater inflater;
    Context mContext;
    FloatingActionButton floatingActionButton;
    //khai bao list khoan thu
    ArrayList<KhoanThu> arrKhoanThu = new ArrayList<>();
    RecyclerView recyclerViewKhoanThu;
    KhoanThu_Adapter khoanThu_adapter;
    KhoanThuDao khoanThuDao;
    //khai bao list loai thu
    LoaiThuDao loaiThuDao;
    ArrayList<LoaiThu> arrLoaiThu = new ArrayList<>();
    int idLoaiThu = 1;
    Fragment_Loai_Thu fragment_loai_thu;

    Spinner spnLoaiThu;
    EditText ed_ten_khoan_thu, ed_so_tien_thu, ed_ghi_chu, ed_ngay_thu;
    ImageView img_ngay_thu;
    Button btn_them_khoan_thu, btn_huy_them_khoan_thu;
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_khoan_thu, container, false);

        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }



    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        floatingActionButton = view.findViewById(R.id.float_btn_khoan_thu);

        fragment_loai_thu = new Fragment_Loai_Thu();

        //anh xa view dialog
        inflater = getLayoutInflater();
        viewKhoanThu = inflater.inflate(R.layout.dialog_khoan_thu, null);
       //khoi tai list recycleview
        recyclerViewKhoanThu = view.findViewById(R.id.recycleView_khoan_thu);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        recyclerViewKhoanThu.setLayoutManager(layoutManager);
        //render list khoan thu
        khoanThuDao = new KhoanThuDao(mContext);
        arrKhoanThu = khoanThuDao.danhSachKhoanThu();
        khoanThu_adapter = new KhoanThu_Adapter(mContext,arrKhoanThu);
        recyclerViewKhoanThu.setAdapter(khoanThu_adapter);




        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewKhoanThu.getParent() != null) {
                    ((ViewGroup)viewKhoanThu.getParent()).removeAllViews();
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setView(viewKhoanThu);




                spnLoaiThu = viewKhoanThu.findViewById(R.id.spn_loai_thu_alert);
                ed_ten_khoan_thu = viewKhoanThu.findViewById(R.id.ed_ten_khoan_thu_alert);
                ed_so_tien_thu = viewKhoanThu.findViewById(R.id.ed_so_tien_thu_khoan_thu_alert);
                ed_ghi_chu = viewKhoanThu.findViewById(R.id.ed_ghi_chu_thu_alert);
                ed_ngay_thu = viewKhoanThu.findViewById(R.id.ed_ngay_thu_alert);
                img_ngay_thu = viewKhoanThu.findViewById(R.id.img_ngay_thu_alert);
                btn_huy_them_khoan_thu = viewKhoanThu.findViewById(R.id.btn_dialog_huy_khoan_thu);
                btn_them_khoan_thu = viewKhoanThu.findViewById(R.id.btn_dialog_them_khoan_thu);

                //custom ngay thu
                img_ngay_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        DatePickerDialog datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                ed_ngay_thu.setText(i2 + "/"+ (i1 + 1) + "/" + i);
                            }
                        }, calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();
                    }
                });

                //lay list ten loai thu sang ben khoan thu
                loaiThuDao = new LoaiThuDao(mContext);
                arrLoaiThu = loaiThuDao.danhSachLoaiThu();
                List <String> arr_ten_loai_thu = new ArrayList<>();
                for (int i = 0; i < arrLoaiThu.size(); i++) {
                    arr_ten_loai_thu.add(arrLoaiThu.get(i).getTenLoaiThu());
                }

                //custom spn
                ArrayAdapter adapter = new ArrayAdapter(mContext, android.R.layout.simple_spinner_item, arr_ten_loai_thu);
                spnLoaiThu.setAdapter(adapter);
                spnLoaiThu.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        idLoaiThu = i + 1;
                        item_spn = arr_ten_loai_thu.get(i);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });



                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                Button btnHuy = viewKhoanThu.findViewById(R.id.btn_dialog_huy_khoan_thu);
                btnHuy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });

                btn_them_khoan_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        KhoanThu khoanThu = new KhoanThu(idLoaiThu, item_spn,  ed_ten_khoan_thu.getText().toString(), ed_ngay_thu.getText().toString(),ed_so_tien_thu.getText().toString(), ed_ghi_chu.getText().toString());
                        khoanThuDao.themKhoanThu(khoanThu);
                        arrKhoanThu = new ArrayList<>();
                        arrKhoanThu = khoanThuDao.danhSachKhoanThu();
                        khoanThu_adapter = new KhoanThu_Adapter(mContext, arrKhoanThu);
                        recyclerViewKhoanThu.setAdapter(khoanThu_adapter);
                        alertDialog.dismiss();
                    }
                });
            }
        });

    }

}
