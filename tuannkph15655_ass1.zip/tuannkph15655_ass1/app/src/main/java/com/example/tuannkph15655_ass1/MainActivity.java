package com.example.tuannkph15655_ass1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.tuannkph15655_ass1.chi.Fragment_Collection_Chi;
import com.example.tuannkph15655_ass1.database.Database;
import com.example.tuannkph15655_ass1.gioithieu.Fragment_Gioi_Thieu;
import com.example.tuannkph15655_ass1.thongke.Fragment_Thong_ke;
import com.example.tuannkph15655_ass1.thu.Fragment_Collection_Thu;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;

import org.jetbrains.annotations.NotNull;

public class  MainActivity extends AppCompatActivity {
    MaterialToolbar toolbar;
    DrawerLayout drawerLayout;
    NavigationView navigationView;

    FragmentManager fragmentManager;
    Fragment_Collection_Thu fragment_collection_thu;
    Fragment_Collection_Chi fragment_collection_chi;
    Fragment_Thong_ke fragment_thong_ke;
    Fragment_Gioi_Thieu fragment_gioi_thieu;

    View viewOut;
    LayoutInflater inflater;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Context context = this;
        //anh xa view out
        inflater =getLayoutInflater();
        viewOut = inflater.inflate(R.layout.dialog_thoat_app, null);

        Database database = new Database(this);
        database.getWritableDatabase();
        toolbar = findViewById(R.id.toolbar_app);
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(Color.WHITE);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.icon_menu_drawer);
        actionBar.setDisplayHomeAsUpEnabled(true);

        drawerLayout = findViewById(R.id.drawer_app);
        navigationView = findViewById(R.id.menu_drawer);

        fragment_collection_thu = new Fragment_Collection_Thu();
        fragment_collection_chi = new Fragment_Collection_Chi();
        fragment_thong_ke = new Fragment_Thong_ke();
        fragment_gioi_thieu = new Fragment_Gioi_Thieu();

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().add(R.id.fragment_container, fragment_collection_thu).commit();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.khoanthu_menu:
                        fragmentManager.beginTransaction().replace(R.id.fragment_container, fragment_collection_thu).commit();
                        break;
                    case R.id.khoanchi_menu:
                        fragmentManager.beginTransaction().replace(R.id.fragment_container, fragment_collection_chi).commit();
                        break;
                    case R.id.thongke_menu:
                        fragmentManager.beginTransaction().replace(R.id.fragment_container, fragment_thong_ke).commit();
                        break;
                    case R.id.gioithieu_menu:
                        fragmentManager.beginTransaction().replace(R.id.fragment_container, fragment_gioi_thieu).commit();
                        break;
                    case R.id.thoat_menu:
                            if(viewOut.getParent() != null) {
                                ((ViewGroup)viewOut.getParent()).removeAllViews();
                            }

                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setView(viewOut);

                        Button btn_thoat_app, btn_huy_thoat_app;
                        btn_huy_thoat_app = viewOut.findViewById(R.id.btn_dialog_huy_thoat_app);
                        btn_thoat_app = viewOut.findViewById(R.id.btn_dialog_thoat_app);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();

                        btn_thoat_app.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.dismiss();
                                MainActivity.this.finish();
                            }
                        });
                        btn_huy_thoat_app.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.dismiss();
                            }
                        });
                        break;
                }
                drawerLayout.closeDrawer(navigationView);
                return false;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home) {
            drawerLayout.openDrawer(navigationView);
        }
        return  super.onOptionsItemSelected(item);
    }


}