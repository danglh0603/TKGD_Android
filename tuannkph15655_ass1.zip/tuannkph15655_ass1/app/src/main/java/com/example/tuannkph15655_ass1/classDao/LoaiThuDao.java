package com.example.tuannkph15655_ass1.classDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.example.tuannkph15655_ass1.classs.LoaiThu;
import com.example.tuannkph15655_ass1.database.Database;

import java.util.ArrayList;
import java.util.List;

public class LoaiThuDao {
    SQLiteDatabase sqLiteDatabase;
    Database database;
    private Context context;
    public LoaiThuDao(Context context) {
        database = new Database(context);
        sqLiteDatabase = database.getWritableDatabase();
    }
    public static final String TABLE_NAME_LOAITHU = Database.TABLE_NAME_LOAITHU;

    public void themLoaiThu(LoaiThu loaiThu) {
        ContentValues values = new ContentValues();
        //values.put("idLoaiThu", loaiThu.getIdLoaiThu());
        values.put("tenLoaiThu", loaiThu.getTenLoaiThu());

        long kq = sqLiteDatabase.insert(TABLE_NAME_LOAITHU, null, values);
        if (kq > 0) {
            Log.e("them thanh cong" , "fsdf");

        } else {
            Toast.makeText(context, "Them that bai", Toast.LENGTH_LONG).show();
        }
    }
    public void suaLoaiThu(LoaiThu loaiThu) {

        ContentValues values = new ContentValues();
        values.put("tenLoaiThu", loaiThu.getTenLoaiThu());

        long kq = sqLiteDatabase.update(TABLE_NAME_LOAITHU, values, "idLoaiThu=?", new String[]{loaiThu.getIdLoaiThu()+ ""});
        if (kq > 0) {
            Log.e("sua thanh cong", "hh");
        } else {
            Log.e("sua that bai", "hh");
        }
    }
    public void xoaLoaiThu(int maLoaiThu) {

        ContentValues values = new ContentValues();

        long kq = sqLiteDatabase.delete(TABLE_NAME_LOAITHU, "idLoaiThu=?", new String[]{maLoaiThu + ""});
        if (kq > 0) {
           Log.e("Xoa thanh cong", "hh");
        } else {
            Log.e("Xoa that bai", "hh");
        }
    }
    public ArrayList<LoaiThu> danhSachLoaiThu() {
        ArrayList<LoaiThu> listLoaiThu = new ArrayList<LoaiThu>();
        String getAll = "select*from " + TABLE_NAME_LOAITHU;
        Cursor cursor = sqLiteDatabase.rawQuery(getAll, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int idLoaiThu = cursor.getInt(0);
                String tenLoaiThu = cursor.getString(1);
                LoaiThu loaiThu  = new LoaiThu(idLoaiThu, tenLoaiThu);
                listLoaiThu.add(loaiThu);
                cursor.moveToNext();
            }
        }
        return listLoaiThu;
    }
}
