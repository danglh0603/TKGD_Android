package com.example.tuannkph15655_ass1.classs;

public class LoaiChi {
    private int idLoaiChi;
    private String tenLoaiChi;

    public LoaiChi() {
    }

    public LoaiChi(int idLoaiChi, String tenLoaiChi) {
        this.idLoaiChi = idLoaiChi;
        this.tenLoaiChi = tenLoaiChi;
    }
    public LoaiChi( String tenLoaiChi) {
        this.tenLoaiChi = tenLoaiChi;
    }

    public int getIdLoaiChi() {
        return idLoaiChi;
    }

    public void setIdLoaiChi(int idLoaiChi) {
        this.idLoaiChi = idLoaiChi;
    }

    public String getTenLoaiChi() {
        return tenLoaiChi;
    }

    public void setTenLoaiChi(String tenLoaiChi) {
        this.tenLoaiChi = tenLoaiChi;
    }
}
