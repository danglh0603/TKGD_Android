package com.example.tuannkph15655_ass1.chi;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.adapter.KhoanChi_Adapter;
import com.example.tuannkph15655_ass1.adapter.KhoanThu_Adapter;
import com.example.tuannkph15655_ass1.adapter.LoaiChi_Adapter;
import com.example.tuannkph15655_ass1.classDao.KhoanChiDao;
import com.example.tuannkph15655_ass1.classDao.KhoanThuDao;
import com.example.tuannkph15655_ass1.classDao.LoaiChiDao;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.KhoanChi;
import com.example.tuannkph15655_ass1.classs.KhoanThu;
import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.classs.LoaiThu;
import com.example.tuannkph15655_ass1.thu.Fragment_Loai_Thu;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Fragment_Khoan_Chi extends Fragment {
    View viewKhoanChi;
    LayoutInflater inflater;
    Context mContext;
    FloatingActionButton floatingActionButton;

    //custom list loai chi
    ArrayList<KhoanChi> arrKhoanChi = new ArrayList<>();
    RecyclerView recyclerViewKhoanChi;
    KhoanChi_Adapter khoanChi_adapter;
    KhoanChiDao khoanChiDao;



    //khai bao list loai thu
    LoaiChiDao loaiChiDao;
    ArrayList<LoaiChi> arrLoaiChi = new ArrayList<>();
    int idLoaiChi = 1;
    //item spn ngay thu
    String item_spn;
    Spinner spnLoaiChi;
    EditText ed_ten_khoan_chi, ed_so_tien_chi, ed_ghi_chu, ed_ngay_chi;
    ImageView img_ngay_chi;
    Button btn_them_khoan_chi, btn_huy_them_khoan_chi;
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_khoan_chi, container, false);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        floatingActionButton = view.findViewById(R.id.float_btn_khoan_chi);

        inflater = getLayoutInflater();
        viewKhoanChi = inflater.inflate(R.layout.dialog_khoan_chi, null);

        recyclerViewKhoanChi = view.findViewById(R.id.recycleView_khoan_chi);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        recyclerViewKhoanChi.setLayoutManager(layoutManager);
        //list loaithu
        khoanChiDao = new KhoanChiDao(mContext);
        arrKhoanChi = (ArrayList<KhoanChi>) khoanChiDao.danhSachKhoanChi();
        khoanChi_adapter = new KhoanChi_Adapter(mContext, arrKhoanChi);
        recyclerViewKhoanChi.setAdapter(khoanChi_adapter);




        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (viewKhoanChi.getParent() != null) {
                    ((ViewGroup) viewKhoanChi.getParent()).removeAllViews();
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setView(viewKhoanChi);

                spnLoaiChi = viewKhoanChi.findViewById(R.id.spn_loai_chi_alert);
                ed_ten_khoan_chi = viewKhoanChi.findViewById(R.id.ed_ten_khoan_chi_alert);
                ed_so_tien_chi = viewKhoanChi.findViewById(R.id.ed_so_tien_thu_khoan_chi_alert);
                ed_ghi_chu = viewKhoanChi.findViewById(R.id.ed_ghi_chu_chi_alert);
                ed_ngay_chi = viewKhoanChi.findViewById(R.id.ed_ngay_chi_alert);
                img_ngay_chi = viewKhoanChi.findViewById(R.id.img_ngay_chi_alert);
                btn_huy_them_khoan_chi = viewKhoanChi.findViewById(R.id.btn_dialog_huy_khoan_chi);
                btn_them_khoan_chi = viewKhoanChi.findViewById(R.id.btn_dialog_them_khoan_chi);


                //custom ngay thu
                img_ngay_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        DatePickerDialog datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                ed_ngay_chi.setText(i2 + "/"+ (i1 + 1) + "/" + i);
                            }
                        }, calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();
                    }
                });

                //lay list ten loai thu sang ben khoan thu
                loaiChiDao = new LoaiChiDao(mContext);
                arrLoaiChi = loaiChiDao.danhSachLoaiChi();
                List <String> arr_ten_loai_thu = new ArrayList<>();
                for (int i = 0; i < arrLoaiChi.size(); i++) {
                    arr_ten_loai_thu.add(arrLoaiChi.get(i).getTenLoaiChi());
                }
                //custom spn
                ArrayAdapter adapter = new ArrayAdapter(mContext, android.R.layout.simple_spinner_item, arr_ten_loai_thu);
                spnLoaiChi.setAdapter(adapter);
                spnLoaiChi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        idLoaiChi = i + 1;
                        item_spn = arr_ten_loai_thu.get(i);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                btn_huy_them_khoan_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });

                btn_them_khoan_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        KhoanChi khoanChi = new KhoanChi(idLoaiChi, item_spn,  ed_ten_khoan_chi.getText().toString(), ed_ngay_chi.getText().toString(),ed_so_tien_chi.getText().toString(), ed_ghi_chu.getText().toString());
                        khoanChiDao.themKhoanChi(khoanChi);
                        arrKhoanChi = new ArrayList<>();
                        arrKhoanChi = khoanChiDao.danhSachKhoanChi();
                        khoanChi_adapter = new KhoanChi_Adapter(mContext, arrKhoanChi);
                        recyclerViewKhoanChi.setAdapter(khoanChi_adapter);
                        alertDialog.dismiss();
                    }
                });

            }
        });
    }
}
