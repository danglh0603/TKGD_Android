package com.example.tuannkph15655_ass1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

public class Login_Activity extends AppCompatActivity {
    TextInputEditText ed_username, ed_pass;
    Button btn_dang_nhap;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ed_username = findViewById(R.id.ed_username);
        ed_pass = findViewById(R.id.ed_password);
        btn_dang_nhap = findViewById(R.id.btn_dang_nhap);


        btn_dang_nhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed_pass.getText().toString().matches("admin") && ed_pass.getText().toString().matches("admin")) {
                    Log.e("vao duoc", "a");
                    intent = new Intent(Login_Activity.this, MainActivity.class);

                    startActivity(intent);
                    ed_username.setText("");
                    ed_pass.setText("");
                } else {
                    Log.e("vao duoc", ed_pass.getText().toString() + "==" + ed_pass.getText().toString());
                }
            }
        });
    }
}