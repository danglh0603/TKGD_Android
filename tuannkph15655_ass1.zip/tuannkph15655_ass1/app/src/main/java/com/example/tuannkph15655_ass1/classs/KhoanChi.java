package com.example.tuannkph15655_ass1.classs;

public class KhoanChi {
    private  int idKhoanChi, idLoaiChi;
    private String  tenKhoanChi,ngayChi,noiDung;
    private String soTienChi, tenLoaiChi;

    public KhoanChi() {
    }

    public KhoanChi(int idKhoanChi, int idLoaiChi,String tenLoaiChi,  String tenKhoanChi, String ngayChi, String noiDung, String soTienChi) {
        this.idKhoanChi = idKhoanChi;
        this.idLoaiChi = idLoaiChi;
        this.tenLoaiChi = tenLoaiChi;
        this.tenKhoanChi = tenKhoanChi;
        this.ngayChi = ngayChi;
        this.noiDung = noiDung;
        this.soTienChi = soTienChi;
    }
    public KhoanChi( int idLoaiChi,String tenLoaiChi, String tenKhoanChi, String ngayChi, String noiDung, String soTienChi) {
        this.idLoaiChi = idLoaiChi;
        this.tenLoaiChi = tenLoaiChi;
        this.tenKhoanChi = tenKhoanChi;
        this.ngayChi = ngayChi;
        this.noiDung = noiDung;
        this.soTienChi = soTienChi;
    }

    public String getTenLoaiChi() {
        return tenLoaiChi;
    }

    public void setTenLoaiChi(String tenLoaiChi) {
        this.tenLoaiChi = tenLoaiChi;
    }

    public int getIdKhoanChi() {
        return idKhoanChi;
    }

    public void setIdKhoanChi(int idKhoanChi) {
        this.idKhoanChi = idKhoanChi;
    }

    public int getIdLoaiChi() {
        return idLoaiChi;
    }

    public void setIdLoaiChi(int idLoaiChi) {
        this.idLoaiChi = idLoaiChi;
    }

    public String getTenKhoanChi() {
        return tenKhoanChi;
    }

    public void setTenKhoanChi(String tenKhoanChi) {
        this.tenKhoanChi = tenKhoanChi;
    }

    public String getNgayChi() {
        return ngayChi;
    }

    public void setNgayChi(String ngayChi) {
        this.ngayChi = ngayChi;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }



    public String getSoTienChi() {
        return soTienChi;
    }

    public void setSoTienChi(String soTienChi) {
        this.soTienChi = soTienChi;
    }
}