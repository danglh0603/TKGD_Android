package com.example.tuannkph15655_ass1.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.tuannkph15655_ass1.classDao.KhoanChiDao;
import com.example.tuannkph15655_ass1.classDao.KhoanThuDao;
import com.example.tuannkph15655_ass1.classDao.LoaiChiDao;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.LoaiThu;

public class Database extends SQLiteOpenHelper {
    Context context;
    public static final String DATABASE_NAME = "assignment";
    public  static final int VERSION_DB = 1;
    public Database(Context context) {
        super(context, DATABASE_NAME, null, VERSION_DB);
        this.context = context;
    }
    public static final String TABLE_NAME_KHOANCHI = "khoanchi";
    public static final String TABLE_NAME_KHOANTHU = "khoanthu";
    public static final String TABLE_NAME_LOAICHI = "loaichi";
    public static final String TABLE_NAME_LOAITHU = "loaithu";
    
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String TABLE_LOAICHI = "create table " +TABLE_NAME_LOAICHI+ "(" +
                "idLoaiChi integer primary key AUTOINCREMENT," +
                " tenLoaiChi nvarchar)";

        String TABLE_LOAITHU = "create table " + TABLE_NAME_LOAITHU + "(" +
                "idLoaiThu integer primary key AUTOINCREMENT," +
                " tenLoaiThu nvarchar)";

        String TABLE_KHOANCHI = "create table " + TABLE_NAME_KHOANCHI+ "(" +
                "idKhoanChi integer primary key AUTOINCREMENT, " +
                "idLoaiChi integer ," +
                "tenLoaiChi nvarchar," +
                "tenKhoanChi nvarchar," +
                "ngayChi date," +
                "soTien float," +
                "noiDung nvarchar," +
                "FOREIGN KEY (idLoaiChi) REFERENCES "+ TABLE_NAME_LOAICHI+ "(idLoaiChi))";

        String TABLE_KHOANTHU = "create table " + TABLE_NAME_KHOANTHU + "(" +
                "idKhoanThu integer  primary key AUTOINCREMENT," +
                "idLoaiThu integer," +
                "tenLoaiThu nvarchar," +
                "tenKhoanThu nvarchar," +
                "ngayThu date," +
                "soTien float," +
                "noiDung varchar," +
                "FOREIGN KEY (idLoaiThu) REFERENCES "+ TABLE_NAME_LOAITHU+ "(idLoaiThu))";

        sqLiteDatabase.execSQL(TABLE_KHOANCHI);
        sqLiteDatabase.execSQL(TABLE_KHOANTHU);
        sqLiteDatabase.execSQL(TABLE_LOAITHU);
        sqLiteDatabase.execSQL(TABLE_LOAICHI);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
