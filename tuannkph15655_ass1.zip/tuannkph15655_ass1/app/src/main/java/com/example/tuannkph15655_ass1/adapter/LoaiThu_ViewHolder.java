package com.example.tuannkph15655_ass1.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;

import org.jetbrains.annotations.NotNull;

public class LoaiThu_ViewHolder extends RecyclerView.ViewHolder {
    TextView tv_ten_loai_thu;
    ImageView img_sua_loai_thu, img_xoa_loai_thu;
    public LoaiThu_ViewHolder(@NonNull @NotNull View itemView) {
        super(itemView);
        tv_ten_loai_thu = itemView.findViewById(R.id.tv_ten_loai_thu);
        img_sua_loai_thu = itemView.findViewById(R.id.img_sua_item_loai_thu);
        img_xoa_loai_thu = itemView.findViewById(R.id.img_xoa_item_loai_thu);
    }
}
