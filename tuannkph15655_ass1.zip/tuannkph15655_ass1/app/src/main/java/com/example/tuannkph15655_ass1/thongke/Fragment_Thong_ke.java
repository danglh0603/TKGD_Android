package com.example.tuannkph15655_ass1.thongke;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.classDao.KhoanThuDao;
import com.example.tuannkph15655_ass1.classs.KhoanThu;

import org.jetbrains.annotations.NotNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Fragment_Thong_ke extends Fragment {
    Context mContext;
    String thoiGianDau, thoiGianSau;
    KhoanThuDao khoanThuDao;
    ArrayList<KhoanThu> arrKhoanThu = new ArrayList<>();
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_thong_ke, container, false);
        return  view;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }


    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        ImageView imgBatDau, imgKetThuc;
        EditText ed_bat_dau, ed_ket_thuc;
        Button btntest;
        imgBatDau = view.findViewById(R.id.img_ngay_bat_dau);
        imgKetThuc = view.findViewById(R.id.img_ngay_ket_thuc);
        ed_bat_dau = view.findViewById(R.id.ed_ngay_bat_dau);
        ed_ket_thuc = view.findViewById(R.id.ed_ngay_ket_thuc);
        khoanThuDao = new KhoanThuDao(mContext);


        imgBatDau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        ed_bat_dau.setText(i2 + "-"+ (i1 + 1) + "-" + i);

                        android.text.format.DateFormat dateFormat = new android.text.format.DateFormat();
                        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
                        String chuoiDateLuu = ed_bat_dau.getText().toString();
                        try{
                            Date objNgay = format.parse(chuoiDateLuu);
                            thoiGianDau = (String) dateFormat.format("yyyy-MM-dd",objNgay);
                            Log.e("thoi gian dau", thoiGianDau);
                        } catch (ParseException e) {
                            Log.e("zzzzzzz", "onCreate: Xảy ra lỗi chuyển kiểu ngày tháng ");
                            e.printStackTrace();
                        }
                    }
                }, calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();


            }
        });






        imgKetThuc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                DatePickerDialog datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        ed_ket_thuc.setText(i2 + "-"+ (i1 + 1) + "-" + i);

                        android.text.format.DateFormat dateFormat = new android.text.format.DateFormat();
                        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
                        String chuoiDateLuu = ed_ket_thuc.getText().toString();
                        try{
                            Date objNgay = format.parse(chuoiDateLuu);
                            thoiGianSau = (String) dateFormat.format("yyyy-MM-dd",objNgay);
                            Log.e("thoi gian sau", thoiGianSau);
                        } catch (ParseException e) {
                            Log.e("zzzzzzz", "onCreate: Xảy ra lỗi chuyển kiểu ngày tháng ");
                            e.printStackTrace();
                        }
                    }
                }, calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });

    }
}
