package com.example.tuannkph15655_ass1.classDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.example.tuannkph15655_ass1.classs.KhoanChi;
import com.example.tuannkph15655_ass1.classs.KhoanThu;
import com.example.tuannkph15655_ass1.database.Database;
import java.util.ArrayList;
import java.util.List;

public class KhoanChiDao {
    SQLiteDatabase sqLiteDatabase;
    Database database;
    private Context context;

    public KhoanChiDao(Context context) {
        database = new Database(context);
        sqLiteDatabase = database.getWritableDatabase();
    }

    public static final String TABLE_NAME_KHOANCHI = Database.TABLE_NAME_KHOANCHI;

    public void themKhoanChi(KhoanChi khoanchi){
        ContentValues values = new ContentValues();

        //values.put("idKhoanChi",khoanchi.getIdKhoanChi());
        values.put("idLoaiChi", khoanchi.getIdLoaiChi());
        values.put("tenLoaiChi", khoanchi.getTenLoaiChi());
        values.put("tenKhoanChi", khoanchi.getTenKhoanChi());
        values.put("ngayChi", khoanchi.getNgayChi());
        values.put("soTien",khoanchi.getSoTienChi());
        values.put("noiDung", khoanchi.getNoiDung());

        long kq = sqLiteDatabase.insert(TABLE_NAME_KHOANCHI,null,values);
        if(kq >0){
            Log.e("them ", "thanh cong");
        }else {
            Log.e("them ", "khong thanh cong");
        }

    }
    public void suaKhoanChi(KhoanChi khoanchi){
        ContentValues values = new ContentValues();
//        values.put("idKhoanChi",khoanchi.getIdKhoanChi());
//        values.put("idLoaiChi", khoanchi.getIdLoaiChi());
        values.put("tenLoaiChi", khoanchi.getTenLoaiChi());
        values.put("tenKhoanChi", khoanchi.getTenKhoanChi());
        values.put("ngayChi", khoanchi.getNgayChi());
        values.put("soTien",khoanchi.getSoTienChi());
        values.put("noiDung", khoanchi.getNoiDung());


        long kq = sqLiteDatabase.update(TABLE_NAME_KHOANCHI,values,"idkhoanchi=?",new String[]{khoanchi.getIdKhoanChi()+ ""});
        if(kq >0){
            Log.e("sua ", "thanh cong");
        }else {
            Log.e("sua ", "khong thanh cong");
        }

    }
    public void xoaKhoanChi(KhoanChi khoanchi){
        ContentValues values = new ContentValues();


        long kq = sqLiteDatabase.delete(TABLE_NAME_KHOANCHI,"idKhoanChi=?",new String[]{khoanchi.getIdKhoanChi()+ ""});
        if(kq >0){
            Log.e("xoa ", "thanh cong");
        }else {
            Log.e("xoa ", "khong thanh cong");
        }

    }

    public ArrayList<KhoanChi> danhSachKhoanChi() {
        ArrayList<KhoanChi> listKhoanChi = new ArrayList<KhoanChi>();
        String getAll = "select*from " + TABLE_NAME_KHOANCHI;
        Cursor cursor = sqLiteDatabase.rawQuery(getAll, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int idKhoanChi = cursor.getInt(0);
                int idLoaiChi = cursor.getInt(1);
                String tenLoaiChi = cursor.getString(2);
                String tenKhoanChi = cursor.getString(3);
                String ngayChi = cursor.getString(4);
                String soTien = cursor.getString(5);
                String noiDung = cursor.getString(6);



                KhoanChi khoanChi = new KhoanChi(idKhoanChi, idLoaiChi, tenLoaiChi,  tenKhoanChi, ngayChi, noiDung, soTien);
                listKhoanChi.add(khoanChi);
                cursor.moveToNext();
            }
        }
        return listKhoanChi;
    }
}
