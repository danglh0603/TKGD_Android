package com.example.tuannkph15655_ass1.chi;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.tuannkph15655_ass1.R;

import org.jetbrains.annotations.NotNull;

public class Adapter_Pager_Chi extends FragmentStateAdapter {
    int soLuongTab = 2;
    public Adapter_Pager_Chi(@NonNull @NotNull Fragment fragment) {
        super(fragment);
    }

    @NonNull
    @NotNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 1:
                return new Fragment_Khoan_Chi();
            default: return new Fragment_Loai_Chi();
        }
    }

    @Override
    public int getItemCount() {
        return soLuongTab;
    }
}
