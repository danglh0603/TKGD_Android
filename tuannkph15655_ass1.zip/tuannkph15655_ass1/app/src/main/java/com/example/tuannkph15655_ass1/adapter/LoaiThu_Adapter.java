package com.example.tuannkph15655_ass1.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.LoaiThu;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class LoaiThu_Adapter extends RecyclerView.Adapter<LoaiThu_ViewHolder> {
    Context context;
    ArrayList<LoaiThu> arrLoaiThu;
    LoaiThuDao loaiThuDao;

    View viewXoaLoaiThu, viewSuaLoaiThu;
    LayoutInflater inflater;

    public LoaiThu_Adapter(Context context, ArrayList<LoaiThu> arrLoaiThu) {
        this.context = context;
        this.arrLoaiThu = arrLoaiThu;
    }

    @NonNull
    @NotNull
    @Override
    public LoaiThu_ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View viewItem = inflater.inflate(R.layout.custom_item_loai_thu, parent, false);
        LoaiThu_ViewHolder loaiThu_viewHolder = new LoaiThu_ViewHolder(viewItem);
        return loaiThu_viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull LoaiThu_ViewHolder holder, int position) {
        LoaiThu loaiThu = arrLoaiThu.get(position);
        holder.tv_ten_loai_thu.setText(loaiThu.getTenLoaiThu());
        loaiThuDao = new LoaiThuDao(context);

        //anh xa dialog view out trong list recycleview
        inflater = LayoutInflater.from(context);
        viewXoaLoaiThu = inflater.inflate(R.layout.dialog_xoa_item, null);
        viewSuaLoaiThu = inflater.inflate(R.layout.dialog_sua_item_loai_thu, null);

        //click de hien thi dialog xoa
        holder.img_xoa_loai_thu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewXoaLoaiThu.getParent() != null) {
                    ((ViewGroup)viewXoaLoaiThu.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewXoaLoaiThu);

                Button btn_xoa_loai_thu, btn_huy_xoa_loai_thu;
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                //anh xa
                btn_xoa_loai_thu = viewXoaLoaiThu.findViewById(R.id.btn_dialog_xoa_item);
                //click de xoa
                btn_xoa_loai_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loaiThuDao.xoaLoaiThu(loaiThu.getIdLoaiThu());
                        arrLoaiThu.remove(loaiThu);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_xoa_loai_thu = viewXoaLoaiThu.findViewById(R.id.btn_dialog_huy_xoa_item);
                btn_huy_xoa_loai_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });

            }
        });

        //click de hien thi dialog sua item
        holder.img_sua_loai_thu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewSuaLoaiThu.getParent() != null) {
                    ((ViewGroup)viewSuaLoaiThu.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewSuaLoaiThu);

                EditText ed_ten_loai_thu_sua = viewSuaLoaiThu.findViewById(R.id.ed_sua_loai_thu_alert);
                Button btn_sua_loai_thu, btn_huy_sua_loai_thu;
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                //anh xa
                btn_sua_loai_thu = viewSuaLoaiThu.findViewById(R.id.btn_dialog_sua_loai_thu);
                btn_sua_loai_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        LoaiThu loaiThu1 = new LoaiThu(loaiThu.getIdLoaiThu(), ed_ten_loai_thu_sua.getText().toString());
                        arrLoaiThu.set(position, loaiThu1);
                        loaiThuDao.suaLoaiThu(loaiThu1);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_sua_loai_thu = viewSuaLoaiThu.findViewById(R.id.btn_dialog_huy_sua_loai_thu);
                btn_huy_sua_loai_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrLoaiThu.size();
    }
}
