package com.example.tuannkph15655_ass1.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.classDao.LoaiChiDao;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.classs.LoaiThu;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class LoaiChi_Adapter extends RecyclerView.Adapter<LoaiChi_ViewHolder> {
    Context context;
    ArrayList<LoaiChi> arrLoaiChi;
    LoaiChiDao loaiChiDao;

    //khai bao view alert dialog sua va xoa
    View viewXoaLoaiChi, viewSuaLoaiChi;
    LayoutInflater inflater;
    public LoaiChi_Adapter(Context context, ArrayList<LoaiChi> arrLoaiChi) {
        this.context = context;
        this.arrLoaiChi = arrLoaiChi;
    }

    @NonNull
    @NotNull
    @Override
    public LoaiChi_ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View viewItem = inflater.inflate(R.layout.custom_item_loai_chi, parent, false);
        LoaiChi_ViewHolder loaiChi_viewHolder = new LoaiChi_ViewHolder(viewItem);
        return loaiChi_viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull LoaiChi_ViewHolder holder, int position) {
        //custom item lay tu database
        LoaiChi loaiChi = arrLoaiChi.get(position);
        loaiChiDao = new LoaiChiDao(context);
        holder.tv_ten_loai_chi.setText(loaiChi.getTenLoaiChi());

        //anh xa  view xoa va sua loai chi
        inflater = LayoutInflater.from(context);
        viewXoaLoaiChi = inflater.inflate(R.layout.dialog_xoa_item, null);
        viewSuaLoaiChi = inflater.inflate(R.layout.dialog_sua_item_loai_chi, null);


        holder.img_xoa_loai_chi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewXoaLoaiChi.getParent() != null) {
                    ((ViewGroup)viewXoaLoaiChi.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewXoaLoaiChi);

                Button btn_xoa_loai_chi, btn_huy_xoa_loai_chi;
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                //anh xa
                btn_xoa_loai_chi = viewXoaLoaiChi.findViewById(R.id.btn_dialog_xoa_item);
                //click de xoa
                btn_xoa_loai_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loaiChiDao.XoaLoaichi(loaiChi.getIdLoaiChi());
                        arrLoaiChi.remove(loaiChi);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_xoa_loai_chi = viewXoaLoaiChi.findViewById(R.id.btn_dialog_huy_xoa_item);
                btn_huy_xoa_loai_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });

            }
        });

        //click de hien thi dialog sua item
        holder.img_sua_loai_chi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewSuaLoaiChi.getParent() != null) {
                    ((ViewGroup)viewSuaLoaiChi.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewSuaLoaiChi);

                EditText ed_ten_loai_chi_sua = viewSuaLoaiChi.findViewById(R.id.ed_sua_loai_chi_alert);
                Button btn_sua_loai_chi, btn_huy_sua_loai_chi;
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                //anh xa
                Log.e("loai chi id:", loaiChi.getIdLoaiChi() + "");
                btn_sua_loai_chi = viewSuaLoaiChi.findViewById(R.id.btn_dialog_sua_loai_chi);
                btn_sua_loai_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        LoaiChi loaiChi1 = new LoaiChi(loaiChi.getIdLoaiChi(), ed_ten_loai_chi_sua.getText().toString());
                        arrLoaiChi.set(position, loaiChi1);
                        loaiChiDao.suaLoaiChi(loaiChi1);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_sua_loai_chi = viewSuaLoaiChi.findViewById(R.id.btn_dialog_huy_sua_loai_chi);
                btn_huy_sua_loai_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrLoaiChi.size();
    }
}
