package com.example.tuannkph15655_ass1.thu;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import org.jetbrains.annotations.NotNull;

public class Adapter_Pager_Thu extends FragmentStateAdapter {
    int soLuongTab = 2;

    public Adapter_Pager_Thu(@NonNull @NotNull Fragment fragment) {
        super(fragment);
    }

    @NonNull
    @NotNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                 return  new Fragment_Loai_Thu();
            case 1:
                 return new Fragment_Khoan_Thu();
            default:  return new Fragment_Loai_Thu();
        }
    }

    @Override
    public int getItemCount() {
        return soLuongTab;
    }
}
