package com.example.tuannkph15655_ass1.adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.classDao.KhoanChiDao;
import com.example.tuannkph15655_ass1.classDao.KhoanThuDao;
import com.example.tuannkph15655_ass1.classDao.LoaiChiDao;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.KhoanChi;
import com.example.tuannkph15655_ass1.classs.KhoanThu;
import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.classs.LoaiThu;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class KhoanChi_Adapter extends RecyclerView.Adapter<KhoanChi_ViewHolder> {


    String item_spn;
    int idLoaiChi = 1;
    LoaiChiDao loaiChiDao;
    ArrayList<LoaiChi> arrLoaiChi = new ArrayList<>();

    Context context;
    ArrayList<KhoanChi> arrKhoanChi;
    KhoanChiDao khoanChiDao;

    View viewXoaKhoanChi, viewSuaKhoanChi;
    LayoutInflater inflater;
    public KhoanChi_Adapter(Context context, ArrayList<KhoanChi> arrKhoanChi) {
        this.context = context;
        this.arrKhoanChi = arrKhoanChi;
    }

    @NonNull
    @NotNull
    @Override
    public KhoanChi_ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View viewItem = inflater.inflate(R.layout.custom_item_khoan_chi, parent, false);
        KhoanChi_ViewHolder khoanChi_viewHolder = new KhoanChi_ViewHolder(viewItem);
        return khoanChi_viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull KhoanChi_ViewHolder holder, int position) {

        khoanChiDao = new KhoanChiDao(context);
        KhoanChi khoanChi = arrKhoanChi.get(position);

        holder.tv_ten_khoan_chi.setText(khoanChi.getTenKhoanChi());
        holder.tv_ghi_chu.setText(khoanChi.getNoiDung());
        holder.tv_ngay_chi.setText(khoanChi.getNgayChi());
        holder.tv_so_tien_chi.setText(khoanChi.getSoTienChi());
        holder.tv_ten_loai_chi_ben_khoan_chi.setText(khoanChi.getTenLoaiChi());
        //anh xa  view xoa va sua loai chi
        inflater = LayoutInflater.from(context);
        viewXoaKhoanChi = inflater.inflate(R.layout.dialog_xoa_item, null);
        viewSuaKhoanChi = inflater.inflate(R.layout.dialog_sua_item_khoan_chi, null);

        holder.img_xoa_khoan_chi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewXoaKhoanChi.getParent() != null) {
                    ((ViewGroup)viewXoaKhoanChi.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewXoaKhoanChi);

                Button btn_xoa_khoan_chi, btn_huy_xoa_khoan_chi;
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                //anh xa
                btn_xoa_khoan_chi = viewXoaKhoanChi.findViewById(R.id.btn_dialog_xoa_item);
                //click de xoa
                btn_xoa_khoan_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        khoanChiDao.xoaKhoanChi(khoanChi);
                        arrKhoanChi.remove(khoanChi);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_xoa_khoan_chi = viewXoaKhoanChi.findViewById(R.id.btn_dialog_huy_xoa_item);
                btn_huy_xoa_khoan_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
            }
        });
        holder.img_sua_khoan_chi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewSuaKhoanChi.getParent() != null) {
                    ((ViewGroup)viewSuaKhoanChi.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewSuaKhoanChi);

                EditText ed_sua_ten_khoan_chi = viewSuaKhoanChi.findViewById(R.id.ed_sua_ten_khoan_chi_alert);
                EditText ed_sua_so_tien_khoan_chi = viewSuaKhoanChi.findViewById(R.id.ed_sua_so_tien_thu_khoan_chi_alert);
                EditText ed_sua_ngay_chi = viewSuaKhoanChi.findViewById(R.id.ed_sua_ngay_chi_alert);
                ImageView img_sua_ngay_chi = viewSuaKhoanChi.findViewById(R.id.img_sua_ngay_chi_alert);
                EditText ed_sua_ghi_chu_chi = viewSuaKhoanChi.findViewById(R.id.ed_sua_ghi_chu_chi_alert);
                Spinner spinner_sua_loai_chi = viewSuaKhoanChi.findViewById(R.id.spn_sua_loai_chi_alert);

                Button btn_huy_sua_khoan_thu = viewSuaKhoanChi.findViewById(R.id.btn_dialog_huy_sua_khoan_chi);
                Button btn_sua_khoan_thu = viewSuaKhoanChi.findViewById(R.id.btn_dialog_sua_khoan_chi);

                //custom ngay thu
                img_sua_ngay_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        DatePickerDialog datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                ed_sua_ngay_chi.setText(i2 + "/"+ (i1 + 1) + "/" + i);
                            }
                        }, calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();
                    }
                });

                //custom list loai thu
                loaiChiDao = new LoaiChiDao(context);
                arrLoaiChi = loaiChiDao.danhSachLoaiChi();
                List<String> arr_ten_loai_chi = new ArrayList<>();
                for (int i = 0; i < arrLoaiChi.size(); i++) {
                    arr_ten_loai_chi.add(arrLoaiChi.get(i).getTenLoaiChi());
                }

                //custom spn
                ArrayAdapter adapter = new ArrayAdapter(context, android.R.layout.simple_spinner_item, arr_ten_loai_chi);
                spinner_sua_loai_chi.setAdapter(adapter);
                spinner_sua_loai_chi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        idLoaiChi = i + 1;
                        item_spn = arr_ten_loai_chi.get(i);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                //anh xa
                btn_sua_khoan_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        KhoanChi khoanChi1 = new KhoanChi(khoanChi.getIdKhoanChi(),idLoaiChi, item_spn,  ed_sua_ten_khoan_chi.getText().toString(), ed_sua_ngay_chi.getText().toString(),ed_sua_so_tien_khoan_chi.getText().toString(), ed_sua_ghi_chu_chi.getText().toString());
                        arrKhoanChi.set(position, khoanChi1);
                        khoanChiDao.suaKhoanChi(khoanChi1);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_sua_khoan_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrKhoanChi.size();
    }
}
