package com.example.tuannkph15655_ass1.adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.classDao.KhoanThuDao;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.KhoanThu;
import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.classs.LoaiThu;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class KhoanThu_Adapter extends RecyclerView.Adapter<KhoanThu_ViewHolder> {
    String item_spn;
    int idLoaiThu = 1;
    LoaiThuDao loaiThuDao;
    ArrayList<LoaiThu> arrLoaiThu = new ArrayList<>();

    Context context;
    ArrayList<KhoanThu> arrKhoanThu;
    KhoanThuDao khoanThuDao;

    View viewXoaKhoanThu, viewSuaKhoanThu;
    LayoutInflater inflater;
    public KhoanThu_Adapter(Context context, ArrayList<KhoanThu> arrKhoanThu) {
        this.context = context;
        this.arrKhoanThu = arrKhoanThu;
    }

    @NonNull
    @NotNull
    @Override
    public KhoanThu_ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View viewItem = inflater.inflate(R.layout.custom_item_khoan_thu, parent, false);
        KhoanThu_ViewHolder khoanThu_viewHolder = new KhoanThu_ViewHolder(viewItem);
        return khoanThu_viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull KhoanThu_ViewHolder holder, int position) {

        khoanThuDao = new KhoanThuDao(context);
        KhoanThu khoanThu = arrKhoanThu.get(position);
        holder.tv_ten_khoan_thu.setText(khoanThu.getTenKhoanThu());
        holder.tv_ghi_chu.setText(khoanThu.getNoiDung());
        holder.tv_ngay_thu.setText(khoanThu.getNgayThu());
        holder.tv_so_tien_thu.setText(khoanThu.getSoTienThu());
        holder.tv_ten_loai_thu_ben_khoan_thu.setText(khoanThu.getTenLoaiThu());
        //anh xa  view xoa va sua loai chi
        inflater = LayoutInflater.from(context);
        viewXoaKhoanThu = inflater.inflate(R.layout.dialog_xoa_item, null);
        viewSuaKhoanThu = inflater.inflate(R.layout.dialog_sua_item_khoan_thu, null);

        holder.img_xoa_khoan_thu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(khoanThu.getIdKhoanThu() + "", "id");
                if(viewXoaKhoanThu.getParent() != null) {
                    ((ViewGroup)viewXoaKhoanThu.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewXoaKhoanThu);

                Button btn_xoa_khoan_thu, btn_huy_xoa_khoan_thu;
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                //anh xa
                btn_xoa_khoan_thu = viewXoaKhoanThu.findViewById(R.id.btn_dialog_xoa_item);
                //click de xoa
                btn_xoa_khoan_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        khoanThuDao.xoaKhoanThu(khoanThu);
                        arrKhoanThu.remove(khoanThu);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_xoa_khoan_thu = viewXoaKhoanThu.findViewById(R.id.btn_dialog_huy_xoa_item);
                btn_huy_xoa_khoan_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
            }
        });
        holder.img_sua_khoan_thu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(viewSuaKhoanThu.getParent() != null) {
                    ((ViewGroup)viewSuaKhoanThu.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setView(viewSuaKhoanThu);

                EditText ed_sua_ten_khoan_thu = viewSuaKhoanThu.findViewById(R.id.ed_sua_ten_khoan_thu_alert);
                EditText ed_sua_so_tien_khoan_thu = viewSuaKhoanThu.findViewById(R.id.ed_sua_so_tien_thu_khoan_thu_alert);
                EditText ed_sua_ngay_thu = viewSuaKhoanThu.findViewById(R.id.ed_sua_ngay_thu_alert);
                ImageView img_sua_ngay_thu = viewSuaKhoanThu.findViewById(R.id.img_sua_ngay_thu_alert);
                EditText ed_sua_ghi_chu_thu = viewSuaKhoanThu.findViewById(R.id.ed_sua_ghi_chu_thu_alert);
                Spinner spinner_sua_loai_thu = viewSuaKhoanThu.findViewById(R.id.spn_sua_loai_thu_alert);

                Button btn_huy_sua_khoan_thu = viewSuaKhoanThu.findViewById(R.id.btn_dialog_huy_sua_khoan_thu);
                Button btn_sua_khoan_thu = viewSuaKhoanThu.findViewById(R.id.btn_dialog_sua_khoan_thu);

                //custom ngay thu
                img_sua_ngay_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        DatePickerDialog datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                ed_sua_ngay_thu.setText(i2 + "/"+ (i1 + 1) + "/" + i);
                            }
                        }, calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH));
                        datePickerDialog.show();
                    }
                });

                //custom list loai thu
                loaiThuDao = new LoaiThuDao(context);
                arrLoaiThu = loaiThuDao.danhSachLoaiThu();
                List<String> arr_ten_loai_thu = new ArrayList<>();
                for (int i = 0; i < arrLoaiThu.size(); i++) {
                    arr_ten_loai_thu.add(arrLoaiThu.get(i).getTenLoaiThu());
                }
                //custom spn
                ArrayAdapter adapter = new ArrayAdapter(context, android.R.layout.simple_spinner_item, arr_ten_loai_thu);
                spinner_sua_loai_thu.setAdapter(adapter);
                spinner_sua_loai_thu.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        idLoaiThu = i + 1;
                        item_spn = arr_ten_loai_thu.get(i);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                //anh xa
                btn_sua_khoan_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        KhoanThu khoanThu1 = new KhoanThu(khoanThu.getIdKhoanThu(),idLoaiThu, item_spn,  ed_sua_ten_khoan_thu.getText().toString(), ed_sua_ngay_thu.getText().toString(),ed_sua_so_tien_khoan_thu.getText().toString(), ed_sua_ghi_chu_thu.getText().toString());
                        arrKhoanThu.set(position, khoanThu1);
                        khoanThuDao.suaKhoanThu(khoanThu1);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });
                btn_huy_sua_khoan_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrKhoanThu.size();
    }
}
