package com.example.tuannkph15655_ass1.classs;

public class KhoanThu {
    private  int idKhoanThu, idLoaiThu;
    private String  tenKhoanThu,ngayThu,noiDung;
    private String soTienThu, tenLoaiThu;

    public KhoanThu() {
    }

    public KhoanThu(int idKhoanThu, int idLoaiThu,String tenLoaiThu, String tenKhoanThu, String ngayThu, String soTienThu, String noiDung) {
        this.idKhoanThu = idKhoanThu;
        this.idLoaiThu = idLoaiThu;
        this.tenLoaiThu = tenLoaiThu;
        this.tenKhoanThu = tenKhoanThu;
        this.ngayThu = ngayThu;
        this.noiDung = noiDung;
        this.soTienThu = soTienThu;
    }
    public KhoanThu( int idLoaiThu,String tenLoaiThu,  String tenKhoanThu, String ngayThu, String noiDung, String soTienThu) {
        this.tenLoaiThu = tenLoaiThu;
        this.idLoaiThu = idLoaiThu;
        this.tenKhoanThu = tenKhoanThu;
        this.ngayThu = ngayThu;
        this.noiDung = noiDung;
        this.soTienThu = soTienThu;
    }

    public String getTenLoaiThu() {
        return tenLoaiThu;
    }

    public void setTenLoaiThu(String loaiThu) {
        this.tenLoaiThu = loaiThu;
    }

    public int getIdKhoanThu() {
        return idKhoanThu;
    }

    public void setIdKhoanThu(int idKhoanThu) {
        this.idKhoanThu = idKhoanThu;
    }

    public int getIdLoaiThu() {
        return idLoaiThu;
    }

    public void setIdLoaiThu(int idLoaiThu) {
        this.idLoaiThu = idLoaiThu;
    }

    public String getTenKhoanThu() {
        return tenKhoanThu;
    }

    public void setTenKhoanThu(String tenKhoanThu) {
        this.tenKhoanThu = tenKhoanThu;
    }

    public String getNgayThu() {
        return ngayThu;
    }

    public void setNgayThu(String ngayThu) {
        this.ngayThu = ngayThu;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }


    public String getSoTienThu() {
        return soTienThu;
    }

    public void setSoTienThu(String soTienThu) {
        this.soTienThu = soTienThu;
    }
}
