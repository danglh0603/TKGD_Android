package com.example.tuannkph15655_ass1.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;

import org.jetbrains.annotations.NotNull;

public class KhoanChi_ViewHolder extends RecyclerView.ViewHolder {
    TextView tv_ten_khoan_chi, tv_ten_loai_chi_ben_khoan_chi, tv_ngay_chi, tv_ghi_chu, tv_so_tien_chi;
    ImageView img_sua_khoan_chi, img_xoa_khoan_chi;
    public KhoanChi_ViewHolder(@NonNull @NotNull View itemView) {
        super(itemView);
        tv_ten_khoan_chi = itemView.findViewById(R.id.tv_ten_khoan_chi);
        tv_ten_loai_chi_ben_khoan_chi = itemView.findViewById(R.id.tv_loai_chi_ben_khoan_chi);
        tv_ngay_chi = itemView.findViewById(R.id.tv_ngay_chi);
        tv_ghi_chu = itemView.findViewById(R.id.tv_ghi_chu_khoan_chi);
        tv_so_tien_chi = itemView.findViewById(R.id.tv_so_tien_chi);
        img_sua_khoan_chi = itemView.findViewById(R.id.img_sua_item_khoan_chi);
        img_xoa_khoan_chi = itemView.findViewById(R.id.img_xoa_item_khoan_chi);
    }
}
