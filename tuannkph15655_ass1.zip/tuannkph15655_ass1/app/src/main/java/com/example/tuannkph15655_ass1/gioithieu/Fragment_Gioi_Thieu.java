package com.example.tuannkph15655_ass1.gioithieu;

import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.tuannkph15655_ass1.R;

import org.jetbrains.annotations.NotNull;

public class Fragment_Gioi_Thieu extends Fragment {
    WebView webView;
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_gioi_thieu, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        webView = view.findViewById(R.id.webview);
        String unencodedHtml =
                "<html><body> " +"<h2 style=\"text-align: center;\">Thong tin app</h2>\n" +
                        " <p><b>Ten phan mem</b></p>\n" +
                        "                <p><b>Quan li thu chi</b></p>\n" +
                        "                <hr>\n" +
                        "                <p><b>Ngay tao</b></p>\n" +
                        "                <p><b>25/07/2021</b></p>\n" +
                        "                <hr>\n" +
                        "                <p><b>Lop</b></p>\n" +
                        "                <p><b>CP16301</b></p>\n" +
                        "                <hr>\n" +
                        "                <p><b>Chuyen nganh</b></p>\n" +
                        "                <p><b>Lap trinh mobile</b></p></body></html>";
        String encodedHtml = Base64.encodeToString(unencodedHtml.getBytes(),
                Base64.NO_PADDING);
        webView.loadData(encodedHtml, "text/html", "base64");
    }
}
