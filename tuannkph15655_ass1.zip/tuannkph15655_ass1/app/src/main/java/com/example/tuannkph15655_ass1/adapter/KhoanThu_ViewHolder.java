package com.example.tuannkph15655_ass1.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;

import org.jetbrains.annotations.NotNull;

public class KhoanThu_ViewHolder extends RecyclerView.ViewHolder {
    TextView tv_ten_khoan_thu, tv_ten_loai_thu_ben_khoan_thu, tv_ngay_thu, tv_ghi_chu, tv_so_tien_thu;
    ImageView img_sua_khoan_thu, img_xoa_khoan_thu;
    public KhoanThu_ViewHolder(@NonNull @NotNull View itemView) {
        super(itemView);
        tv_ten_khoan_thu = itemView.findViewById(R.id.tv_ten_khoan_thu);
        tv_ten_loai_thu_ben_khoan_thu = itemView.findViewById(R.id.tv_loai_thu_ben_khoan_thu);
        tv_ngay_thu = itemView.findViewById(R.id.tv_ngay_thu);
        tv_so_tien_thu = itemView.findViewById(R.id.tv_so_tien_thu);
        tv_ghi_chu = itemView.findViewById(R.id.tv_ghi_chu_khoan_thu);
        img_sua_khoan_thu = itemView.findViewById(R.id.img_sua_item_khoan_thu);
        img_xoa_khoan_thu = itemView.findViewById(R.id.img_xoa_item_khoan_thu);
    }
}
