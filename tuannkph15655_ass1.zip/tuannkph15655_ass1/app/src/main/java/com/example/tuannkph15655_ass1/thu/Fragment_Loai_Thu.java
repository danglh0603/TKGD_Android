package com.example.tuannkph15655_ass1.thu;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.adapter.LoaiThu_Adapter;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.classs.LoaiThu;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class Fragment_Loai_Thu extends Fragment {
    //custom view dialog
    LayoutInflater inflater;
    View viewDialogAddLoaiThu;
    FloatingActionButton floatingActionButton;
    Context mContext;
    //custom list loai thu
    ArrayList<LoaiThu> arrLoaiThu = new ArrayList<>();
    RecyclerView recyclerViewLoaiThu;
    LoaiThu_Adapter loaiThu_adapter;
    LoaiThuDao loaiThuDao;
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_loai_thu, container, false);
        return  view;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        //anh xa dialog
        inflater =getLayoutInflater();
        viewDialogAddLoaiThu = inflater.inflate(R.layout.dialog_add_loai_thu, null);
        floatingActionButton = view.findViewById(R.id.float_btn_loai_thu);

        recyclerViewLoaiThu = view.findViewById(R.id.recycleView_loai_thu);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        recyclerViewLoaiThu.setLayoutManager(layoutManager);
        //list loaithu
        loaiThuDao = new LoaiThuDao(mContext);
        arrLoaiThu = loaiThuDao.danhSachLoaiThu();
        loaiThu_adapter = new LoaiThu_Adapter(mContext,arrLoaiThu);
        recyclerViewLoaiThu.setAdapter(loaiThu_adapter);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewDialogAddLoaiThu.getParent() != null) {
                    Log.e("ko null", "fsds");
                    ((ViewGroup)viewDialogAddLoaiThu.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setView(viewDialogAddLoaiThu);
                EditText ed_ten_loai_thu = viewDialogAddLoaiThu.findViewById(R.id.ed_ten_loai_thu_alert);

                Button btn_them_loai_thu = viewDialogAddLoaiThu.findViewById(R.id.btn_dialog_them_loai_thu);


                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                Button btnHuy = viewDialogAddLoaiThu.findViewById(R.id.btn_dialog_huy_loai_thu);
                btnHuy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
                btn_them_loai_thu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        LoaiThu loaiThu = new LoaiThu(ed_ten_loai_thu.getText().toString());
                        Log.e(loaiThu.getTenLoaiThu() , "ten loai thu");
                        loaiThuDao.themLoaiThu(loaiThu);
                        arrLoaiThu = new ArrayList<>();
                        arrLoaiThu = loaiThuDao.danhSachLoaiThu();
                        loaiThu_adapter = new LoaiThu_Adapter(mContext, arrLoaiThu);
                        recyclerViewLoaiThu.setAdapter(loaiThu_adapter);
                        alertDialog.dismiss();
                    }
                });
            }
        });
    }
}
