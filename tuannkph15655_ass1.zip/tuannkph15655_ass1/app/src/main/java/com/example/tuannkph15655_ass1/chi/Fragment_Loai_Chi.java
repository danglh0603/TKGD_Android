package com.example.tuannkph15655_ass1.chi;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tuannkph15655_ass1.R;
import com.example.tuannkph15655_ass1.adapter.LoaiChi_Adapter;
import com.example.tuannkph15655_ass1.adapter.LoaiThu_Adapter;
import com.example.tuannkph15655_ass1.classDao.LoaiChiDao;
import com.example.tuannkph15655_ass1.classDao.LoaiThuDao;
import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.classs.LoaiThu;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class Fragment_Loai_Chi extends Fragment {
    LayoutInflater inflater;
    View viewDialogAddLoaiChi;
    FloatingActionButton floatingActionButton;
    Context mContext;
    //custom list loai chi
    ArrayList<LoaiChi> arrLoaiChi = new ArrayList<>();
    RecyclerView recyclerViewLoaiChi;
    LoaiChi_Adapter loaiChi_adapter;
    LoaiChiDao loaiChiDao;
    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_loai_chi, container, false);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }
    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        inflater =getLayoutInflater();
        viewDialogAddLoaiChi = inflater.inflate(R.layout.dialog_add_loai_chi, null);
        floatingActionButton = view.findViewById(R.id.float_btn_loai_chi);


        recyclerViewLoaiChi = view.findViewById(R.id.recycleView_loai_chi);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext);
        recyclerViewLoaiChi.setLayoutManager(layoutManager);
        //list loaichi
        loaiChiDao = new LoaiChiDao(mContext);
        arrLoaiChi = loaiChiDao.danhSachLoaiChi();
        loaiChi_adapter = new LoaiChi_Adapter(mContext,arrLoaiChi);
        recyclerViewLoaiChi.setAdapter(loaiChi_adapter);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(viewDialogAddLoaiChi.getParent() != null) {
                    ((ViewGroup)viewDialogAddLoaiChi.getParent()).removeAllViews();
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setView(viewDialogAddLoaiChi);

                EditText ed_ten_loai_chi = viewDialogAddLoaiChi.findViewById(R.id.ed_ten_loai_chi_alert);

                Button btn_them_loai_chi = viewDialogAddLoaiChi.findViewById(R.id.btn_dialog_them_loai_chi);
                Button btn_huy_them_chi = viewDialogAddLoaiChi.findViewById(R.id.btn_dialog_huy_loai_chi);
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                btn_them_loai_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        LoaiChi loaiChi = new LoaiChi(ed_ten_loai_chi.getText().toString());
                        Log.e(loaiChi.getTenLoaiChi() , "ten loai chi");
                        loaiChiDao.themLoaiChi(loaiChi);
                        arrLoaiChi = new ArrayList<>();
                        arrLoaiChi = loaiChiDao.danhSachLoaiChi();
                        loaiChi_adapter = new LoaiChi_Adapter(mContext, arrLoaiChi);
                        recyclerViewLoaiChi.setAdapter(loaiChi_adapter);
                        alertDialog.dismiss();
                    }
                });
                btn_huy_them_chi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.cancel();
                    }
                });
            }
        });
    }
}
