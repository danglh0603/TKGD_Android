package com.example.tuannkph15655_ass1.classDao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.example.tuannkph15655_ass1.classs.LoaiChi;
import com.example.tuannkph15655_ass1.database.Database;

import java.util.ArrayList;
import java.util.List;

public class LoaiChiDao {
    SQLiteDatabase sqLiteDatabase;
    Database database;
    private Context context;
    public LoaiChiDao(Context context) {
        database = new Database(context);
        sqLiteDatabase = database.getWritableDatabase();
    }
    public static final String TABLE_NAME_LOAICHI = Database.TABLE_NAME_LOAICHI;

    public void themLoaiChi(LoaiChi loaiChi) {
        ContentValues values = new ContentValues();
        //values.put("idLoaiChi", loaiChi.getIdLoaiChi());
        values.put("tenLoaiChi", loaiChi.getTenLoaiChi());

        long kq = sqLiteDatabase.insert(TABLE_NAME_LOAICHI, null, values);
        if (kq > 0) {
            Log.e("them thanh cong", "hh");
        } else {
            Log.e("them that bai", "hh");
        }
    }
    public void suaLoaiChi(LoaiChi loaiChi) {

        ContentValues values = new ContentValues();
        values.put("tenLoaiChi", loaiChi.getTenLoaiChi());

        long kq = sqLiteDatabase.update(TABLE_NAME_LOAICHI, values, "idLoaiChi=?", new String[]{loaiChi.getIdLoaiChi()+ ""});
        if (kq > 0) {
            Log.e("sua thanh cong", "hh");
        } else {
            Log.e("sua that bai", "hh");
        }
    }
    public void XoaLoaichi(int maLoaiChi) {

        ContentValues values = new ContentValues();

        long kq = sqLiteDatabase.delete(TABLE_NAME_LOAICHI, "idLoaiChi=?", new String[]{maLoaiChi+ ""});
        if (kq > 0) {
            Log.e("xoa thanh cong", "hh");
        } else {
            Log.e("xoa that bai", "hh");
        }
    }

    public ArrayList<LoaiChi> danhSachLoaiChi() {
        ArrayList<LoaiChi> listLoaiChi = new ArrayList<LoaiChi>();
        String getAll = "select*from "+ TABLE_NAME_LOAICHI;
        Cursor cursor = sqLiteDatabase.rawQuery(getAll, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                int idLoaiChi = cursor.getInt(0);
                String tenLoaiChi = cursor.getString(1);
                LoaiChi loaiChi = new LoaiChi(idLoaiChi, tenLoaiChi);
                listLoaiChi.add(loaiChi);
                cursor.moveToNext();
            }
        }
        return listLoaiChi;
    }

}
